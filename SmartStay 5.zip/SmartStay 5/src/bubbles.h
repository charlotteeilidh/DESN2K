
void newbubble(void);
void print_screen(int blind_cont_set, int season_set, int coffee_set, int house_mode_set, int display_mode);
