void touch_read_xy(char *x, char* y);
void touch_init(void);
int button_pressed(char x, char y, int rectX1, int rectX2, int rectY1, int rectY2);
void setup_screen(void);
