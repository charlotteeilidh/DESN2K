void setupADC(void);
int readADC(void);
void displayADC(int val);
void setupLadder(void);
void displayLadder(int val, int scale);
