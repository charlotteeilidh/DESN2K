void away_on(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void away_off(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void relax_on(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void relax_off(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void movie_on(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void movie_off(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void party_on(int *blind_cont_set, int *blind_level, int *asm_blind_level);
void party_off(int *blind_cont_set, int *blind_level, int *asm_blind_level);

#define LEDL_R	(1 << 16)
#define LEDL_G	(1 << 17)
#define LEDL_B	(1 << 18)
#define LEDR_R	(1 << 19)
#define LEDR_G	(1 << 20)
#define LEDR_B	(1 << 21)

