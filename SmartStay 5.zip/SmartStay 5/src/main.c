#include "touch.h"
#include "lcd_grph.h"
#include "lcd_interact.h"
#include "house_modes.h"
#include <stdint.h>
#include <LPC24xx.H>   

#include "light_sensor.h"
#define MID_THRESHOLD	180
#define LOW_THRESHOLD	340

//These numbers are the bit patterns for lighting up the respective LED    
#define LED1	1
#define LED2	2
#define LED3	4
#define LED4	8              

extern void LEDCycle_Init(void);
extern void LEDCycle(unsigned int value);
extern void delay(void);
extern __irq void T0_IRQHandler(void);

extern int play_song(void);

volatile uint8_t led1_state = 0;

void LED1_Set(int on);

void LED2_Set(int on);

#define COFFEE_PIN_MASK 0x00000800  // P0.11 = 0x800


// DOORBELL STUFF
// Constants
#define DOORBELL_PIN_MASK 0x00000400  // P0.10 = 0x400
#define CHIME_PERIOD_US   1000        // 1 kHz = 1000 us period
#define CHIME_DURATION_US 100000      // 100 ms = 100000 us
#define CHIME_VOLUME      0x2FF       // Medium volume (max is 0x3FF)

#define NOTE_C5  1911    // 523 Hz
#define NOTE_E5  1517    // 659 Hz
#define NOTE_G5  1276    // 784 Hz
#define NOTE_C6  955     // 1046 Hz

//#define	FIO0PIN	(*((volatile uint32_t *)0x3FFFC014))

void setup_DAC(void);
void udelay(unsigned int delay_in_us);
void play_tone(unsigned int duration, int period, int vol);


extern void blind_control(int control_value);

int main(void) {
	char x=0, y=0;
	
	// INPUTS FOR APPLIANCE CONTROLL FUCNTIONS HERE
	
	int control_value = 0;													// blinds setting for auto (0)/manual(1)
	int asm_blind_level = 0; 												// asm value for blind control, default to 0 = open
	
	
	// initialise UI button states
	int blind_cont_set = 0; 												// default to 0 = auto
	int season_set = 0;															// default to 0 = winter
	int coffee_set = 1;															//default to 1 = off
	int house_mode_set = 0;													// default to 0 = off (1 party, 2 relax, 3 movie, 4away)
	int display_mode = 0;														// default 0 = regular display (1 = accessible, 2 = manual blind set)
	int blind_level = 0;														// default to no options selected (1 = open, 2 = mid, 3 = closed)
	
	// initialise prev states as current state
	int prev_blind = blind_cont_set;
	int prev_season = season_set;
	int prev_coffee = coffee_set;
	int prev_house_mode = house_mode_set; 
	int prev_display = display_mode;
	int prev_blind_level = blind_level;
	
	//light sensor
	int	adcVal;
	int light_level; // for blind_control
	
	
	/////////////////////////////////////////////////// COFFEE??
	volatile uint8_t led1_blink_flag = 0;
	LEDCycle_Init(); 
	//////////////////////////////////////////////////
	
	//config tricolor leds for output
	FIO3DIR |= LEDL_R | LEDL_G | LEDL_B;  // Make all left LEDs outputs
	
	// setup doorbell
	setup_DAC();

  // Configure P0.10 as input (clear bit 10)
  FIO0DIR &= ~DOORBELL_PIN_MASK;
	
	
	FIO0SET &= 0x0 << 22;
	//initialise lcd display
	setup_screen();
	
	// print initial display screen
	print_screen(blind_cont_set, season_set, coffee_set, house_mode_set, display_mode, blind_level);
	
	// setup touchscreen
	touch_init();
	
	
	
	// Setup done - enter loop
	while (1) {
		// always reset prev states to current states before making changes
		prev_blind = blind_cont_set;
		prev_season = season_set;
		prev_coffee = coffee_set;
		prev_display = display_mode;
		prev_blind_level = blind_level;
		prev_house_mode = house_mode_set; 
		
		// continuously read for touch on UI
    touch_read_xy(&x, &y);
		
		// check specific interactions (if buttons pressed)
		// updates pointer states accordingly
    check_lcd_interaction(x, y, &blind_cont_set, &season_set, &coffee_set, 
			&house_mode_set, &display_mode, &blind_level, &asm_blind_level);
    
		
		adcVal = readADC();
		
		if (adcVal < LOW_THRESHOLD) {
			light_level = 0; // light_level = 00
		} else if (adcVal < MID_THRESHOLD) {
			light_level = 1; //MID
		} else {
			light_level = 3;	// light_level = 11
		}
		
		// push button toggle for coffee set
		if (FIO0PIN & COFFEE_PIN_MASK) {
			udelay(20000);  // debounce
      if (FIO0PIN & COFFEE_PIN_MASK) {
				coffee_set = !coffee_set;
				while((FIO0PIN & COFFEE_PIN_MASK));
			}
		}
			
		//execute led 2 for coffee based on coffee set
		if (coffee_set == 0) {
			LED1_Set(1);
		} else {
			LED1_Set(0);
		}
		
		// if a change has occured due to UI interaction (i.e. button on screen pressed)
    if (blind_cont_set != prev_blind || season_set != prev_season || coffee_set != prev_coffee ||
			house_mode_set != prev_house_mode || display_mode != prev_display || blind_level != prev_blind_level) {
        
			// reprint updated screen if changes made
			print_screen(blind_cont_set, season_set, coffee_set, house_mode_set, display_mode, blind_level);
    }
		
		/*
		// ensure if no house modes activate that extra features are set off/neutral
		if (house_mode_set == 0) {
			displayLadder(0);
		}
		*/
		
		
		
		// rebuild blind control value and execute blind control fn
		control_value = 0;  // reset here
		control_value |= (blind_cont_set & 0x1);
		control_value |= ((season_set & 0x1) << 1);
		control_value |= ((asm_blind_level & 0x3) << 2);
		control_value |= ((light_level & 0x03) << 4); //LIGHT LEVEL INPUT TO COME LATER W SENSOR
		blind_control(control_value);
		
		// EXECUTE DOORBELL FUNCTION (IF BUTTON PRESSED, PLAY SOUND)
		if (FIO0PIN & DOORBELL_PIN_MASK) {
				udelay(20000);  // debounce
			if (FIO0PIN & DOORBELL_PIN_MASK) {

				// ?? Fun Chime Sequence
        play_tone(150000, NOTE_C5, CHIME_VOLUME);
				play_tone(150000, NOTE_E5, CHIME_VOLUME);
				play_tone(150000, NOTE_G5, CHIME_VOLUME);
				play_tone(150000, NOTE_C6, CHIME_VOLUME);

				// Wait for release
				while (FIO0PIN & DOORBELL_PIN_MASK);
			}
		}
		//displayLadder(0);
		// IMPLEMENT AUTO TIMER FUNCTION FOR COFFEE MACHINE W OVERRIDES FROM UI (AND PUSHBUTTON??)
		//coffee set currently determined by LCD ONLY
		
				
		
		// party music
		// if party mode play music
		if (house_mode_set == 1) {
			play_song();
			house_mode_set = 0;
			party_off(&blind_cont_set, &blind_level, &asm_blind_level);
			print_screen(blind_cont_set, season_set, coffee_set, house_mode_set, display_mode, blind_level);
		}
		
    
	}
}

