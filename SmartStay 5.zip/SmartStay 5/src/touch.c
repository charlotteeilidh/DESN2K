#include "touch.h"
#include "lpc24xx.h" 
#include "lcd/lcd_hw.h"
#include "lcd/lcd_grph.h"
#include "lcd/lcd_cfg.h"
#include "lcd/sdram.h"
#include "delay.h"
#include <stdlib.h>

#define CS_PIN            1<<20        //P0.20

static unsigned char touch_read(unsigned char command);

void touch_init(void)
{
	FIO0DIR |= 1<<20;    // P0.20 output
  FIO0SET = CS_PIN;     // CS high (inactive)

  // SCLK on P0.15: PINSEL0 bits 30-31
	//PINSEL0 &= ~(3U << 30);
	PINSEL0 |=  (3 << 30);

	// MOSI on P0.18 and MISO on P0.17 are on PINSEL1 (bits 4-5 and 2-3 respectively)
	PINSEL1 |= ((1 << 4) | (1 << 5));
	PINSEL1 |=  ((1 << 2) | (1 << 3));

    
	S0SPCR = 0x093C;  // Master mode, 8-bit transfer, SPI enabled 
  
	S0SPCCR = 0x24;   // 72MHz/36 = 2MHz SPI clock
}

void touch_read_xy(char *x, char* y)
{
	
	//orig
	//Read X co-ordinate from the touch screen controller
	*x = touch_read(0xD8);
	//Read Y co-ordinate from the touch screen controller
	*y = touch_read(0x98);
}

static unsigned char touch_read(unsigned char command)
{
	unsigned short result;
	//unsigned char high;
	//unsigned char low;

	//Set CS_TP pin low to begin SPI transmission
	FIO0CLR = CS_PIN;
	
	//Transmit command byte on MOSI, ignore MISO (full read write cycle)
	S0SPDR = command;                 // Write command byte to SPI data register to start transfer
  while (!(S0SPSR & (1 << 7)));    // Wait until SPIF (bit 7) is set, indicating transfer complete
	
	//Transmit 0x00 on MOSI, read in requested result on MISO (another full read write cycle)
	S0SPDR = 0x00;                   // Send dummy byte to generate clock for reading data
  while (!(S0SPSR & (1 << 7)));    // Wait for transfer complete
  result = S0SPDR;
	
	//Transmission complete, set CS_TP pin back to high
	FIO0SET = CS_PIN;
	

	//Return 8 bit result.
	return (unsigned char) result;
}	

//Accepts an x and y co-ordinate ranging from 0-255
int button_pressed(char x, char y, int rectX1, int rectX2, int rectY1, int rectY2) {
	//scale the coordinates to the screens resolution
	int point_x = x*240/255;
	int point_y = y*320/255; 
	
	//"pop" the bubble if it the distance is less than the radius
	if (point_x >= rectX1 && point_x <= rectX2 &&
        point_y >= rectY1 && point_y <= rectY2) {
        // Pop and draw a new rectangle bubble
        return 1;
  } else {
		return 0;
	}

	//for debugging purposes draw dots where touches are registered
	//lcd_point(point_x, point_y, BLACK);
}

void setup_screen(void) {
	//Setup external SDRAM. Used for Frame Buffer
	sdramInit();	
	
	//Setup LPC2478 LCD Controller for our specific LCD
	//lcd_config is defined in lcd/lcd_cfg.h
	lcdInit(&lcd_config); 
	
	//Turn the LCD on
	lcdTurnOn();
	
	//Blow the first bubble
	//newbubble();
	
}
