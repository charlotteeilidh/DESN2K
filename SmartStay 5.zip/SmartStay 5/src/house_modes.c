/*
possible input names:
char x, char y, int *blind_cont_set, int *season_set, int *coffee_set, 
													int *house_mode_set, int *display_mode, int *blind_level, int *asm_blind_level

blind level: 1 open, 2 mid, 3 closed
*/

#include <stdint.h>

#define FIO0DIR (*((volatile uint32_t *)0x3FFFC000))  // Port 0 direction register
#define FIO0SET (*((volatile uint32_t *)0x3FFFC018))  // Port 0 set register
#define FIO0CLR (*((volatile uint32_t *)0x3FFFC01C))  // Port 0 clear register

#define FIO2DIR (*((volatile uint32_t *)0x3FFFC040))  // Port 2 direction register
#define FIO2SET (*((volatile uint32_t *)0x3FFFC058))  // Port 2 set register
#define FIO2CLR (*((volatile uint32_t *)0x3FFFC05C))  // Port 2 clear register

//These numbers are the bit patterns for lighting up the respective LED    
#define LED1	1
#define LED2	2
#define LED3	4
#define LED4	8              

extern void LEDCycle_Init(void);
extern void LEDCycle(unsigned int value);
extern void delay(void);




void LED1_Set(int on);

void LED2_Set(int on);


void led_ladder_set(int led_num) {
    // Validate input range
    if (led_num < 0) led_num = 0;
    if (led_num > 8) led_num = 8;

    // Set ladder enable pin (P0.22) high (keep it ON always)
    FIO0DIR |= (1 << 22);   // Set P0.22 as output
    FIO0SET = (1 << 22);    // Enable ladder

    // Set LED pins (P2.1 to P2.8) as outputs
    FIO2DIR |= 0x000001FE;  // bits 1-8 set as outputs

    // Clear all LEDs first (turn off)
    FIO2CLR = 0x000001FE;

    if (led_num > 0) {
        // Create mask for LEDs 1 to led_num (bits 1 to led_num)
        // For example, led_num=3 -> mask = bits 1,2,3 set -> binary 0b1110 = 14 decimal
        unsigned int mask = (1 << (led_num + 1)) - 2;

        // Turn ON LEDs in mask
        FIO2SET = mask;
    }
}

away_on(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    // turn LED ladder ON (full brightness)
    // set blinds manual close
    *blind_cont_set = 1;        //set to MANUAL
    *blind_level = 3;
		*asm_blind_level = 3;

}

away_off(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    // turn off LED ladder
		FIO2SET = 0x000001FE;  // Turn off all LEDs
		FIO0CLR = (1 << 22);   // Disable LED ladder
	
    // set blinds back to auto
    *blind_cont_set = 0;
}

relax_on(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    // turn LED ladder ON (mid brightness e.g. 50%)
		led_ladder_set(4);
	
    // play ambient music continuously through DAC

    // set blinds manual mid
    *blind_cont_set = 1;
    *blind_level = 2;
		*asm_blind_level = 1;

}

relax_off(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    // LED ladder OFF
		FIO2SET = 0x000001FE;  // Turn off all LEDs
		FIO0CLR = (1 << 22);   // Disable LED ladder

    // stop music

    // set blinds back to auto
    *blind_cont_set = 0;
}

movie_on(int *blind_cont_set, int *blind_level, int *asm_blind_level) { 
    // dim lights LED ladder (low level e.g. 25%)
		led_ladder_set(2);

    // blinds manual close
    *blind_cont_set = 1;
    *blind_level = 3;
		*asm_blind_level = 3;

    // TV on (LED 2)
		LED2_Set(1);
	
	

}

movie_off(int *blind_cont_set, int *blind_level, int *asm_blind_level) { 
    // turn OFF LED ladder
		FIO2SET = 0x000001FE;  // Turn off all LEDs
		FIO0CLR = (1 << 22);   // Disable LED ladder
	
    // set blinds back to auto
    *blind_cont_set = 0;

    // turn TV off (LED 2)
		LED2_Set(0);
    
}

party_on(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    // flashing lights (LED ladder cont. up - down)
		led_ladder_set(8);
	
	
    // party music through DAC
		
	
    // blinds manual close
    *blind_cont_set = 1;
    *blind_level = 3;
		*asm_blind_level = 3;

}

party_off(int *blind_cont_set, int *blind_level, int *asm_blind_level) {
    //  lights off (LED ladder)
		FIO2SET = 0x000001FE;  // Turn off all LEDs
		FIO0CLR = (1 << 22);   // Disable LED ladder
	
    // music OFF

    // blinds back to auto
    *blind_cont_set = 0;
}

