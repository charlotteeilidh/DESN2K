#include "lpc24xx.h"
#include "lcd_hw.h"
#include "lcd_grph.h"
#include "font5x7.h"
#include <string.h>

void print_screen(int blind_cont_set, int season_set, int coffee_set, 
													int house_mode_set, int display_mode, int blind_level) {
	if (display_mode == 0) {
		//STANDARD DISPLAY
		//Draw a background with lcd_fillScreen
		//Otherwise you will write random noise to the screen!
		lcd_fillScreen(0xBEFC);
															
		//LOGO - DEPENDS ON HOUSE MODES
		if (house_mode_set == 0) {
			//REGULAR
			lcd_putString_scaled(20, 280, "SmartStay", 3, NAVY, 0xBEFC);
		} else if (house_mode_set == 1) {
			//PARTY
			lcd_putString_scaled(20, 280, "SmartStay", 3, MAGENTA, 0xBEFC);
		} else if (house_mode_set ==2) {
			//RELAX
			lcd_putString_scaled(20, 280, "SmartStay", 3, CYAN, 0xBEFC);
		} else if (house_mode_set == 3) {
			//MOVIE
			lcd_putString_scaled(20, 280, "SmartStay", 3, RED, 0xBEFC);
		} else if (house_mode_set == 4) {
			//AWAY
			lcd_putString_scaled(20, 280, "SmartStay", 3, NAVY, 0xBEFC);
		}
		
		//ACCESIBILITY OPTION - CONSTANT
		lcd_fillRect(190, 270, 220, 300, NAVY);
		lcd_putString_scaled(198, 280, "!!", 2, 0xBEFC, NAVY);													
		
		//BLINDS  LABEL - CONSTANT
		lcd_fillRect(20, 20, 80, 50, NAVY); 		// LABEL
		lcd_putString_scaled(32, 31, (unsigned char *)"BLINDS", 1, WHITE, NAVY);
		
		// VARIABLE CONTROL BUTTONS
		if (blind_cont_set == 0) {
				//AUTO PRESSED
				lcd_fillRect(120, 20, 160, 50, GREEN); 	//AUTO
				lcd_putString_scaled(128, 31, (unsigned char *)"AUTO",1,BLACK, GREEN);

		
				lcd_fillRect(180, 20, 220, 50, LIGHT_GRAY);	// MANUAL
				lcd_putString_scaled(182, 31, (unsigned char *)"MANUAL",1, BLACK, LIGHT_GRAY);
			} else if (blind_cont_set == 1) {
				//MANUAL PRESSED
				lcd_fillRect(120, 20, 160, 50, LIGHT_GRAY); 	//AUTO
				lcd_putString_scaled(128, 31, (unsigned char *)"AUTO",1,BLACK, LIGHT_GRAY);

		
				lcd_fillRect(180, 20, 220, 50, RED);	// MANUAL
				lcd_putString_scaled(182, 31, (unsigned char *)"MANUAL",1, BLACK, RED);
			}
		
		//SEASON LABEL - CONSTANT
		lcd_fillRect(20, 70, 80, 100, NAVY); //SEASON
		lcd_putString_scaled(32, 81, (unsigned char *)"SEASON",1, WHITE, NAVY);
		
		//VARIABLE SEASON CONT BUTTONS
		if (season_set == 0) {
				//WINTER PRESSED
				lcd_fillRect(120, 70, 160, 100, GREEN); // WINTER
				lcd_fontColor(BLACK, GREEN); // BLACK text on green background
				lcd_putString(122, 81, (unsigned char *)"WINTER");

				lcd_fillRect(180, 70, 220, 100, LIGHT_GRAY); // SUMMER
				lcd_fontColor(BLACK, LIGHT_GRAY); // Black text on light gray background
				lcd_putString(182, 81, (unsigned char *)"SUMMER");
			} else if (season_set ==1) {
				//SUMMER PRESSED
				lcd_fillRect(120, 70, 160, 100, LIGHT_GRAY); // WINTER
				lcd_fontColor(BLACK, LIGHT_GRAY); // BLACK text on GRAY background
				lcd_putString(122, 81, (unsigned char *)"WINTER");

				lcd_fillRect(180, 70, 220, 100, RED); // SUMMER
				lcd_fontColor(BLACK, RED); // Black text on RED background
				lcd_putString(182, 81, (unsigned char *)"SUMMER");			
			}
		
		//COFFEE LABEL - CONSTANT
		lcd_fillRect(20, 120, 80, 150, NAVY);
		lcd_putString_scaled(32, 131, (unsigned char *)"COFFEE", 1, WHITE, NAVY);

		//VARIABLE COFFEE CONT BUTTONS (1 OFF 0 ON)
		if (coffee_set == 0) {
				//ON PRESSED
				// ON Button
				lcd_fillRect(120, 120, 160, 150, GREEN); 
				lcd_fontColor(BLACK, GREEN);
				lcd_putString(125, 126, (unsigned char *)"ON");  // Correctly centered

				// OFF Button
				lcd_fillRect(180, 120, 220, 150, LIGHT_GRAY); 
				lcd_fontColor(BLACK, LIGHT_GRAY);
				lcd_putString(182, 126, (unsigned char *)"OFF");  // Correctly centered
			} else if (coffee_set == 1) {
				//OFF PRESSED
				// ON Button
				lcd_fillRect(120, 120, 160, 150, LIGHT_GRAY); 
				lcd_fontColor(BLACK, LIGHT_GRAY);
				lcd_putString(125, 126, (unsigned char *)"ON");  // Correctly centered

				// OFF Button
				lcd_fillRect(180, 120, 220, 150, RED); 
				lcd_fontColor(BLACK, RED);
				lcd_putString(182, 126, (unsigned char *)"OFF");  // Correctly centered
			}
			

		
		//HOUSE MODES LABEL - CONSTANT
		lcd_fillRect(50, 160, 190, 180, NAVY);
		lcd_putString_scaled(87, 166, (unsigned char *)"HOUSE MODES",1, WHITE, NAVY);

		//VARIABLE HOUSE MODE SET (0 NONE, 1 PARTY, 2 RELAX, 3 MOVIE, 4 AWAY
		if (house_mode_set == 0) {
				//NONE
				lcd_fontColor(BLACK, LIGHT_GRAY);
				lcd_fillRect(20, 190, 110, 220, LIGHT_GRAY);
				lcd_putString(50, 201, (unsigned char *)"PARTY");

				lcd_fontColor(BLACK, LIGHT_GRAY);
				// RELAX
				lcd_fillRect(130, 190, 220, 220, LIGHT_GRAY);
				lcd_putString(160, 201, (unsigned char *)"RELAX");

				// MOVIE
				lcd_fillRect(20, 230, 110, 260, LIGHT_GRAY);
				lcd_putString(50, 241, (unsigned char *)"MOVIE");

				// AWAY
				lcd_fillRect(130, 230, 220, 260, LIGHT_GRAY);
				lcd_putString(163, 241, (unsigned char *)"AWAY");	
			} else if (house_mode_set == 1) {
				//PARTY
				lcd_fontColor(BLACK, GREEN);
				lcd_fillRect(20, 190, 110, 220, GREEN);
				lcd_putString(50, 201, (unsigned char *)"PARTY");

				lcd_fontColor(BLACK, LIGHT_GRAY);
				// RELAX
				lcd_fillRect(130, 190, 220, 220, LIGHT_GRAY);
				lcd_putString(160, 201, (unsigned char *)"RELAX");

				// MOVIE
				lcd_fillRect(20, 230, 110, 260, LIGHT_GRAY);
				lcd_putString(50, 241, (unsigned char *)"MOVIE");

				// AWAY
				lcd_fillRect(130, 230, 220, 260, LIGHT_GRAY);
				lcd_putString(163, 241, (unsigned char *)"AWAY");	
			} else if (house_mode_set == 2) {
				//RELAX PRESSED
				// PARTY
				lcd_fontColor(BLACK, GREEN);
				// RELAX
				lcd_fillRect(130, 190, 220, 220, GREEN);
				lcd_putString(160, 201, (unsigned char *)"RELAX");

				lcd_fontColor(BLACK, LIGHT_GRAY);
				
				lcd_fillRect(20, 190, 110, 220, LIGHT_GRAY);
				lcd_putString(50, 201, (unsigned char *)"PARTY");
				// MOVIE
				lcd_fillRect(20, 230, 110, 260, LIGHT_GRAY);
				lcd_putString(50, 241, (unsigned char *)"MOVIE");

				// AWAY
				lcd_fillRect(130, 230, 220, 260, LIGHT_GRAY);
				lcd_putString(163, 241, (unsigned char *)"AWAY");
			} else if (house_mode_set == 3) {
				//MOVIE PRESSED
				// PARTY
				lcd_fontColor(BLACK, GREEN);
				// MOVIE
				lcd_fillRect(20, 230, 110, 260, GREEN);
				lcd_putString(50, 241, (unsigned char *)"MOVIE");
				
				lcd_fontColor(BLACK, LIGHT_GRAY);
				
				// RELAX
				lcd_fillRect(130, 190, 220, 220, LIGHT_GRAY);
				lcd_putString(160, 201, (unsigned char *)"RELAX");
				
				lcd_fillRect(20, 190, 110, 220, LIGHT_GRAY);
				lcd_putString(50, 201, (unsigned char *)"PARTY");
				
				// AWAY
				lcd_fillRect(130, 230, 220, 260, LIGHT_GRAY);
				lcd_putString(163, 241, (unsigned char *)"AWAY");
			} else if (house_mode_set == 4) {
				//AWAY PRESSED
				lcd_fontColor(BLACK, GREEN);
				lcd_fillRect(130, 230, 220, 260, GREEN);
				lcd_putString(163, 241, (unsigned char *)"AWAY");
				
				lcd_fontColor(BLACK, LIGHT_GRAY);
				
				// RELAX
				lcd_fillRect(130, 190, 220, 220, LIGHT_GRAY);
				lcd_putString(160, 201, (unsigned char *)"RELAX");
				
				lcd_fillRect(20, 190, 110, 220, LIGHT_GRAY);
				lcd_putString(50, 201, (unsigned char *)"PARTY");
				
				// MOVIE
				lcd_fillRect(20, 230, 110, 260, LIGHT_GRAY);
				lcd_putString(50, 241, (unsigned char *)"MOVIE");
			}
		}
		
		else if (display_mode == 1) {
			// THIS IS BLIND SELECTION SCREEN
			lcd_fillScreen(0xBEFC);

			// LOGO - CONSTANT
			lcd_putString_scaled(20, 280, "SmartStay", 3, NAVY, 0xBEFC);

			// ACCESSIBILITY OPTION - CONSTANT
			lcd_fillRect(190, 270, 220, 300, NAVY);
			lcd_putString_scaled(198, 280, "!!", 2, 0xBEFC, NAVY);

			// Button 4 - CONFIRM - CONSTANT
			lcd_fillRect(60, 185, 180, 215, NAVY);
			lcd_putString_scaled(80, 190, "CONFIRM", 2, WHITE, NAVY);

			if (blind_level == 0) {
					// OPEN
					lcd_fillRect(60, 65, 180, 95, LIGHT_GRAY);
					lcd_putString_scaled(85, 70, "OPEN", 2, BLACK, LIGHT_GRAY);

					// MIDWAY
					lcd_fillRect(60, 105, 180, 135, LIGHT_GRAY);
					lcd_putString_scaled(78, 110, "MIDWAY", 2, BLACK, LIGHT_GRAY);

					// CLOSED
					lcd_fillRect(60, 145, 180, 175, LIGHT_GRAY);
					lcd_putString_scaled(78, 150, "CLOSED", 2, BLACK, LIGHT_GRAY);

			} else if (blind_level == 1) {
					// OPEN selected
					lcd_fillRect(60, 65, 180, 95, GREEN);
					lcd_putString_scaled(85, 70, "OPEN", 2, BLACK, GREEN);

					lcd_fillRect(60, 105, 180, 135, LIGHT_GRAY);
					lcd_putString_scaled(78, 110, "MIDWAY", 2, BLACK, LIGHT_GRAY);

					lcd_fillRect(60, 145, 180, 175, LIGHT_GRAY);
					lcd_putString_scaled(78, 150, "CLOSED", 2, BLACK, LIGHT_GRAY);

			} else if (blind_level == 2) {
					// MIDWAY selected
					lcd_fillRect(60, 65, 180, 95, LIGHT_GRAY);
					lcd_putString_scaled(85, 70, "OPEN", 2, BLACK, LIGHT_GRAY);

					lcd_fillRect(60, 105, 180, 135, GREEN);
					lcd_putString_scaled(78, 110, "MIDWAY", 2, BLACK, GREEN);

					lcd_fillRect(60, 145, 180, 175, LIGHT_GRAY);
					lcd_putString_scaled(78, 150, "CLOSED", 2, BLACK, LIGHT_GRAY);

			} else if (blind_level == 3) {
					// CLOSED selected
					lcd_fillRect(60, 65, 180, 95, LIGHT_GRAY);
					lcd_putString_scaled(85, 70, "OPEN", 2, BLACK, LIGHT_GRAY);

					lcd_fillRect(60, 105, 180, 135, LIGHT_GRAY);
					lcd_putString_scaled(78, 110, "MIDWAY", 2, BLACK, LIGHT_GRAY);

					lcd_fillRect(60, 145, 180, 175, GREEN);
					lcd_putString_scaled(78, 150, "CLOSED", 2, BLACK, GREEN);
			}
	}
	
	else if (display_mode == 2) {
		//ACCESSIBLE SCREEN
		lcd_fillScreen(0xBEFC);

		// LOGO - CONSTANT
		lcd_putString_scaled(20, 280, "SmartStay", 3, NAVY, 0xBEFC);

		// ACCESSIBILITY OPTION - CONSTANT
		lcd_fillRect(190, 270, 220, 300, NAVY);
		lcd_putString_scaled(198, 280, "!!", 2, 0xBEFC, NAVY);
		
		// ===== SET 1: BLINDS =====
    lcd_fillRect(10, 20, 230, 55, NAVY);
    lcd_putString_scaled(80, 28, "BLINDS", 2, WHITE, NAVY);
		if (blind_cont_set == 0) {
			// AUTO
			lcd_fillRect(10, 60, 115, 95, GREEN);
			lcd_putString_scaled(30, 68, "AUTO", 2, BLACK, GREEN);

			lcd_fillRect(125, 60, 230, 95, LIGHT_GRAY);
			lcd_putString_scaled(140, 68, "MANUAL", 2, BLACK, LIGHT_GRAY);
		} else if (blind_cont_set == 1) {
			// MANUAL
			lcd_fillRect(10, 60, 115, 95, LIGHT_GRAY);
			lcd_putString_scaled(30, 68, "AUTO", 2, BLACK, LIGHT_GRAY);

			lcd_fillRect(125, 60, 230, 95, RED);
			lcd_putString_scaled(140, 68, "MANUAL", 2, BLACK, RED);
		}

    // ===== SET 2: SEASON =====
    lcd_fillRect(10, 110, 230, 145, NAVY);
    lcd_putString_scaled(75, 118, "SEASON", 2, WHITE, NAVY);
		
		if (season_set == 0) {
			// WINTER
			lcd_fillRect(10, 150, 115, 185, GREEN);
			lcd_putString_scaled(22, 158, "WINTER", 2, BLACK, GREEN);

			lcd_fillRect(125, 150, 230, 185, LIGHT_GRAY);
			lcd_putString_scaled(140, 158, "SUMMER", 2, BLACK, LIGHT_GRAY);
		} else if (season_set == 1) {
			// SUMMER
			lcd_fillRect(10, 150, 115, 185, LIGHT_GRAY);
			lcd_putString_scaled(22, 158, "WINTER", 2, BLACK, LIGHT_GRAY);

			lcd_fillRect(125, 150, 230, 185, RED);
			lcd_putString_scaled(140, 158, "SUMMER", 2, BLACK, RED);
		}

    // ===== SET 3: COFFEE (shifted up) =====
    lcd_fillRect(10, 192, 230, 227, NAVY); // was 200-235
    lcd_putString_scaled(72, 200, "COFFEE", 2, WHITE, NAVY);
		
		if (coffee_set == 0) {
			// ON
			lcd_fillRect(10, 232, 115, 267, GREEN); // was 240-275
			lcd_putString_scaled(40, 240, "ON", 2, BLACK, GREEN);

			lcd_fillRect(125, 232, 230, 267, LIGHT_GRAY);
			lcd_putString_scaled(150, 240, "OFF", 2, BLACK, LIGHT_GRAY);
		} else if (coffee_set == 1) {
			// OFF
			lcd_fillRect(10, 232, 115, 267, LIGHT_GRAY); // was 240-275
			lcd_putString_scaled(40, 240, "ON", 2, BLACK, LIGHT_GRAY);

			lcd_fillRect(125, 232, 230, 267, RED);
			lcd_putString_scaled(150, 240, "OFF", 2, BLACK, RED);
		}
	}
}
