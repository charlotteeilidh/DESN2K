void check_lcd_interaction (char x, char y, int *blind_cont_set, int *season_set, int *coffee_set, int *house_mode_set, int *display_mode, int *blind_level, int *asm_blind_level);
void print_screen(int blind_cont_set, int season_set, int coffee_set, int house_mode_set, int display_mode, int blind_level);


#define AUTO_X1 120
#define AUTO_Y1 20
#define AUTO_X2 160
#define AUTO_Y2 50

#define MANUAL_X1 180
#define MANUAL_Y1	20
#define MANUAL_X2	220
#define MANUAL_Y2	50

#define WINTER_X1	120
#define WINTER_Y1	70
#define WINTER_X2	160
#define WINTER_Y2	100

#define SUMMER_X1	180
#define SUMMER_Y1	70
#define SUMMER_X2	220
#define SUMMER_Y2	100

#define	COFFEE_ON_X1	120
#define	COFFEE_ON_Y1	120
#define	COFFEE_ON_X2	160
#define	COFFEE_ON_Y2	150

#define COFFEE_OFF_X1	180
#define COFFEE_OFF_Y1	120
#define COFFEE_OFF_X2	220
#define COFFEE_OFF_Y2	150

#define PARTY_X1	20
#define PARTY_Y1	190
#define PARTY_X2	110
#define PARTY_Y2	220

#define RELAX_X1	130
#define RELAX_Y1	190
#define RELAX_X2	220
#define RELAX_Y2	220

#define	MOVIE_X1	20
#define	MOVIE_Y1	230
#define	MOVIE_X2	110
#define	MOVIE_Y2	260

#define AWAY_X1		130
#define AWAY_Y1		230
#define AWAY_X2		220
#define AWAY_Y2		260

#define	OPEN_X1		60
#define	OPEN_Y1		65
#define	OPEN_X2		180
#define	OPEN_Y2		95

#define MID_X1		60
#define MID_Y1		105
#define MID_X2		180
#define MID_Y2		135

#define CLOSED_X1	60
#define CLOSED_Y1	145
#define CLOSED_X2	180
#define CLOSED_Y2	175

#define	CONFIRM_X1	60
#define	CONFIRM_Y1	185
#define	CONFIRM_X2	180
#define	CONFIRM_Y2	215

#define	ACCESSIBLE_X1	190
#define	ACCESSIBLE_Y1	270
#define	ACCESSIBLE_X2	220
#define	ACCESSIBLE_Y2	300

#define	AUTO2_X1	10
#define	AUTO2_Y1	60
#define	AUTO2_X2	115
#define	AUTO2_Y2	95

#define	MANUAL2_X1	125
#define	MANUAL2_Y1	60
#define	MANUAL2_X2	230
#define	MANUAL2_Y2	95

#define	SUMMER2_X1	125
#define	SUMMER2_Y1	150
#define	SUMMER2_X2	230
#define	SUMMER2_Y2	185

#define	WINTER2_X1	10
#define	WINTER2_Y1	150
#define	WINTER2_X2	115
#define	WINTER2_Y2	185

#define	ON2_X1	10
#define	ON2_Y1	232
#define	ON2_X2	115
#define	ON2_Y2	267

#define	OFF2_X1	125
#define	OFF2_Y1	232
#define	OFF2_X2	230
#define	OFF2_Y2	267
