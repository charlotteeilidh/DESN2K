/******************************************************************************
 *
 * Copyright:
 *    (C) 2005 Embedded Artists AB
 *
 * Description:
 *    Delay functions
 *
 *****************************************************************************/
#ifndef _DELAY_H_
#define _DELAY_H_

void mdelay(unsigned int ms);

#endif
