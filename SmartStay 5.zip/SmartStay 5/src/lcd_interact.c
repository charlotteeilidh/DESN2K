#include "lcd_interact.h"
#include "touch.h"
#include "lcd_grph.h"
#include "house_modes.h"

// check when buttons have been pressed - set flags to execute control + update UI
void check_lcd_interaction (char x, char y, int *blind_cont_set, int *season_set, int *coffee_set, 
													int *house_mode_set, int *display_mode, int *blind_level, int *asm_blind_level) {
																							
	if (*display_mode == 0) {
		// check interactions w default display 
		//CHECK BLINDS SETTING
		if (button_pressed(x, y, AUTO_X1, AUTO_X2, AUTO_Y1, AUTO_Y2)) {
			//AUTO PRESSED
			*blind_cont_set = 0;
			// treat as an off for house modes
			*house_mode_set = 0;
		}
		if (button_pressed(x, y, MANUAL_X1, MANUAL_X2, MANUAL_Y1, MANUAL_Y2)) {
			//MANUAL PRESSED
			*blind_cont_set = 1;
			// SWITCH TO MANUAL BLIND SELECT DISPLAY
			*display_mode = 1;
			// treat as an off for house modes
			*house_mode_set = 0;
		}
		//CHECK SEASON SETTING
		if (button_pressed(x, y, WINTER_X1, WINTER_X2, WINTER_Y1, WINTER_Y2)) {
			//WINTER PRESSED
			*season_set = 0;
		}
		if (button_pressed(x, y, SUMMER_X1, SUMMER_X2, SUMMER_Y1, SUMMER_Y2)) {
			//WINTER PRESSED
			*season_set = 1;			
		}
		// CHECK COFFEE MACHINE PRESSED
		if (button_pressed(x, y, COFFEE_ON_X1, COFFEE_ON_X2, COFFEE_ON_Y1, COFFEE_ON_Y2)) {
			//ON PRESSED
			*coffee_set = 0;
			
			
			///////////////////////////////////////////////
			//EXECUTE COFFEE MACHINE CONTROL UPDATES HERE//
			///////////////////////////////////////////////
			
		}
		
		if (button_pressed(x, y, COFFEE_OFF_X1, COFFEE_OFF_X2, COFFEE_OFF_Y1, COFFEE_OFF_Y2)) {
			//OFF PRESSED
			*coffee_set = 1;
			
			///////////////////////////////////////////////
			//EXECUTE COFFEE MACHINE CONTROL UPDATES HERE//
			///////////////////////////////////////////////
			
		}
		
		
		
		// CHECK HOUSE MODES PRESSED
		if (button_pressed(x, y, PARTY_X1, PARTY_X2, PARTY_Y1, PARTY_Y2)) {
			//PARTY PRESSED
			//if already on turn off, else turn on
			if (*house_mode_set == 1) {
				// TURN OFF
				party_off(blind_cont_set, blind_level, asm_blind_level);
				*house_mode_set = 0;
			} else {
				//MAKE SURE ALL OTHERS OFF
				relax_off(blind_cont_set, blind_level, asm_blind_level);
				movie_off(blind_cont_set, blind_level, asm_blind_level);
				away_off(blind_cont_set, blind_level, asm_blind_level);
				//TURN ON
				*house_mode_set = 1;
				party_on(blind_cont_set, blind_level, asm_blind_level);
			}
		}
		if (button_pressed(x, y, RELAX_X1, RELAX_X2, RELAX_Y1, RELAX_Y2)) {
			// RELAX
			//if already on turn off, else turn on
			if (*house_mode_set == 2) {
				// TURN OFF
				*house_mode_set = 0;
				relax_off(blind_cont_set, blind_level, asm_blind_level);
			} else {
				//MAKE SURE ALL OTHERS OFF
				party_off(blind_cont_set, blind_level, asm_blind_level);
				movie_off(blind_cont_set, blind_level, asm_blind_level);
				away_off(blind_cont_set, blind_level, asm_blind_level);
				*house_mode_set = 2;
				relax_on(blind_cont_set, blind_level, asm_blind_level);
			}			
		}
		if (button_pressed(x, y, MOVIE_X1, MOVIE_X2, MOVIE_Y1, MOVIE_Y2)) {
			//MOVIE PRESSED
			//if already on turn off, else turn on
			if (*house_mode_set == 3) {
				// TURN OFF
				*house_mode_set = 0;
				movie_off(blind_cont_set, blind_level, asm_blind_level);
			} else {
				//MAKE SURE ALL OTHERS OFF
				party_off(blind_cont_set, blind_level, asm_blind_level);
				relax_off(blind_cont_set, blind_level, asm_blind_level);
				away_off(blind_cont_set, blind_level, asm_blind_level);
				// TURN ON
				*house_mode_set = 3;
				movie_on(blind_cont_set, blind_level, asm_blind_level);
			}
		}
		if (button_pressed(x, y, AWAY_X1, AWAY_X2, AWAY_Y1, AWAY_Y2)) {
			//AWAY PRESSED
			//if already on turn off, else turn on
			if (*house_mode_set == 4) {
				//TURN OFF
				*house_mode_set = 0;
				away_off(blind_cont_set, blind_level, asm_blind_level);
			} else {
				//MAKE SURE ALL OTHERS OFF
				party_off(blind_cont_set, blind_level, asm_blind_level);
				relax_off(blind_cont_set, blind_level, asm_blind_level);
				movie_off(blind_cont_set, blind_level, asm_blind_level);
				//TURN ON
				*house_mode_set = 4;
				away_on(blind_cont_set, blind_level, asm_blind_level);
			}
		}
		if (button_pressed(x, y, ACCESSIBLE_X1, ACCESSIBLE_X2, ACCESSIBLE_Y1, ACCESSIBLE_Y2)) {
			//SWITCH TO ACCESSIBLE UI MODE
			*display_mode = 2;
			//FOR ACCESSIBLE MODE TURN OFF HOUSE MODES
			*house_mode_set = 0;
			party_off(blind_cont_set, blind_level, asm_blind_level);
			relax_off(blind_cont_set, blind_level, asm_blind_level);
			movie_off(blind_cont_set, blind_level, asm_blind_level);
			away_off(blind_cont_set, blind_level, asm_blind_level);
		}
	} 
	else if (*display_mode == 1) {
		// blind set display
		// clicked on open, blind level = 1
		if (button_pressed(x, y, OPEN_X1, OPEN_X2, OPEN_Y1, OPEN_Y2)) {
			*blind_level = 1;
		}
		// clicked on mid, blind level = 2
		if (button_pressed(x, y, MID_X1, MID_X2, MID_Y1, MID_Y2)) {
			*blind_level = 2;
		}
		// clicked on closed, blind level = 3
		if (button_pressed(x, y, CLOSED_X1, CLOSED_X2, CLOSED_Y1, CLOSED_Y2)) {
			*blind_level = 3;
		}
		// clicked on confirm, if blind_level != 0, display mode = 0, otherwise stay 
		// i.e. cant confirm until selection made
		if (button_pressed(x, y, CONFIRM_X1, CONFIRM_X2, CONFIRM_Y1, CONFIRM_Y2)) {
			if (*blind_level != 0) {
				*display_mode = 0;
				
				switch (*blind_level) {
					case 0: *asm_blind_level = 0; break;  // None chosen, map to open (red)
					case 1: *asm_blind_level = 0; break;  // Open ? 00 (open)
					case 2: *asm_blind_level = 1; break;  // Mid ? 01 (mid)
					case 3: *asm_blind_level = 3; break;  // Closed ? 11 (closed)
					default: *asm_blind_level = 0; break;
				}
			}
		}
	}
	
	else if (*display_mode == 2) {
		if (button_pressed(x, y, ACCESSIBLE_X1, ACCESSIBLE_X2, ACCESSIBLE_Y1, ACCESSIBLE_Y2)) {
			//SWITCH TO REGULAR UI MODE
			*display_mode = 0;
		}
		
		//CHECK BLINDS SETTING
		if (button_pressed(x, y, AUTO2_X1, AUTO2_X2, AUTO2_Y1, AUTO2_Y2)) {
			//AUTO PRESSED
			*blind_cont_set = 0;
		}
		
		if (button_pressed(x, y, MANUAL2_X1, MANUAL2_X2, MANUAL2_Y1, MANUAL2_Y2)) {
			//MANUAL PRESSED
			*blind_cont_set = 1;
			
			// SWITCH TO MANUAL BLIND SELECT DISPLAY
			*display_mode = 1;
		}
		
		//CHECK SEASON SETTING
		if (button_pressed(x, y, WINTER2_X1, WINTER2_X2, WINTER2_Y1, WINTER2_Y2)) {
			//WINTER PRESSED
			*season_set = 0;
		}
		
		if (button_pressed(x, y, SUMMER2_X1, SUMMER2_X2, SUMMER2_Y1, SUMMER2_Y2)) {
			//WINTER PRESSED
			*season_set = 1;			
		}
		
		// CHECK COFFEE MACHINE PRESSED
		if (button_pressed(x, y, ON2_X1, ON2_X2, ON2_Y1, ON2_Y2)) {
			//ON PRESSED
			*coffee_set = 0;
			
			
			///////////////////////////////////////////////
			//EXECUTE COFFEE MACHINE CONTROL UPDATES HERE//
			///////////////////////////////////////////////
			
		}
		
		if (button_pressed(x, y, OFF2_X1, OFF2_X2, OFF2_Y1, OFF2_Y2)) {
			//OFF PRESSED
			*coffee_set = 1;
			
			///////////////////////////////////////////////
			//EXECUTE COFFEE MACHINE CONTROL UPDATES HERE//
			///////////////////////////////////////////////
			
		}
	}
}

