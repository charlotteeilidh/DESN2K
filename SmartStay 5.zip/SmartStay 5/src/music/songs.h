//Note datatype
struct tone {
	int duration;
	int pitch;
	int volume;
};
