/*extern void blinky_func(void);
void play_song(void);

void Party_Mode(void);  

int main(void) {
    Party_Mode();
    while(1);
    return 0;
}

void Party_Mode(void) {
    blinky_func();
    play_song();
}*/
