#include "songs.h"

// Each note: {Duration, Pitch, Volume}
// Duration scaled by 'rate' in main.c
// Pitch = period in useconds
// Volume: 0 to 0x3FF

#define OFF     100

#define C4      3831
#define CS4     3610
#define D4      3401
#define DS4     3215
#define E4      3030
#define F4      2857
#define FS4     2725
#define G4      2551
#define GS4     2410
#define A4      2272
#define AS4     2146
#define B4      2024

#define C5      C4/2
#define CS5     CS4/2
#define D5      D4/2
#define DS5     DS4/2
#define E5      E4/2
#define F5      F4/2
#define FS5     FS4/2
#define G5      G4/2
#define GS5     GS4/2
#define A5      A4/2
#define AS5     AS4/2
#define B5      B4/2

int song_duration = 48;  // number of notes

struct tone song_data[] = {
    // Intro (inspired by stairway to heaven intro)
    {4,  E4,  0x300},
    {2,  G4,  0x300},
    {2,  A4,  0x300},
    {4,  B4,  0x300},
    {2,  C5,  0x300},
    {2,  B4,  0x300},
    {2,  A4,  0x300},
    {2,  G4,  0x300},

    {4,  E4,  0x300},
    {2,  G4,  0x300},
    {2,  A4,  0x300},
    {4,  B4,  0x300},
    {2,  C5,  0x300},
    {2,  B4,  0x300},
    {2,  A4,  0x300},
    {2,  G4,  0x300},

    // Some melody line variation
    {4,  D5,  0x300},
    {2,  C5,  0x300},
    {2,  B4,  0x300},
    {4,  A4,  0x300},
    {2,  G4,  0x300},
    {2,  F4,  0x300},
    {2,  E4,  0x300},
    {2,  D4,  0x300},

    {4,  C4,  0x300},
    {4,  OFF, 0x0},  // rest for breath

    // Climax inspired melody
    {2,  G4,  0x300},
    {2,  A4,  0x300},
    {1,  B4,  0x300},
    {1,  C5,  0x300},
    {2,  D5,  0x300},
    {2,  E5,  0x300},
    {4,  F5,  0x300},

    {2,  E5,  0x300},
    {2,  D5,  0x300},
    {2,  C5,  0x300},
    {2,  B4,  0x300},
    {2,  A4,  0x300},
    {4,  G4,  0x300},

    {4,  OFF, 0x0},  // rest
};

