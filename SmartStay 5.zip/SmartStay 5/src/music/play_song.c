#include "lpc24xx.h"
#include "songs.h"

extern struct tone song_data[];
extern int song_duration;
extern void udelay(unsigned int delay_in_us);
extern void play_tone(unsigned int duration, int period,  int vol);
extern void setup_DAC(void);

int play_song(void) {

	// Sets the speed at which the song plays.
	int rate = 52000; 
	
	int i = 0;

	// Setup the DAC 
	setup_DAC();
	
	// Play the song
	while(i < song_duration) {
		play_tone(rate * song_data[i].duration, song_data[i].pitch, song_data[i].volume);
		i++;
		
	}
	return 0;
}
