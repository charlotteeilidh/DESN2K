#include "lpc24xx.h"

// Initialize DAC.
// This should be the same as the previous exercise.
void setup_DAC2(void) {
	
	// setup Pin Connect for AOUT 
	PINSEL1 &= ~(3 << 20);  // clear bits 21:20 for P0.26 - pinsel1 is the register for the DAC 
	PINSEL1 |=  (2 << 20);  // set bits to '10' - means DAC output function

}

// udelay should delay the processor for 'delay_in_us' number of microseconds.

// * LPC24XX.h contains a definition for the PCLK, "Fpclk"
//   use this definition for PCLK as defined in the manual.
// * Use Timer 0. This means you MUST use the prefix T0 for every control
//   register, i.e. T0TCR.
// * Make sure you reset the timer, and when you start the timer ENSURE you
//   set the reset bit back to zero!
void udelay2(unsigned int delay_in_us) {
	T0TCR = 0x02; //reset timer control register
	//convert into microseconds 
	T0PR = (Fpclk / 1000000) - 1; // convert prescaler to 1 microsecond 
	
	T0MR0 = delay_in_us; //set match register 0 to delay set in main
	T0MCR = 0x04; // stop once match is reached
	T0TCR = 0x01; // enable timer using timer control register
	while((T0TCR & 0x01) != 0) {
	}
	T0TCR = 0x02; //reset counter 
}
	

// play_tone should play a tone for 'duration' number of microseconds at the pitch
// given by 1/'period'. Played at the volume given by 'vol', which ranges from																   
// 0 (off) to 0x3FF (max volume).																		   

void play_tone2(unsigned int duration, int period, int vol) {
	int i;
	for(i = 0; i < (duration/period); i++) {
		DACR = ((DACR & 0xFFFF003F) | vol << 6);
		udelay(period/2);
		DACR = (DACR & 0xFFFF003F);
		udelay(period/2);
	}
}
