#include "lpc24xx.h"

// -----------------------------
// DAC Setup for P0.26 (AOUT)
// -----------------------------
void setup_DAC(void) {
    // Clear bits 21:20, then set them to 10 for DAC (function 2)
    PINSEL1 &= ~(3 << 20);  // Clear bits for P0.26
    PINSEL1 |=  (2 << 20);  // Set P0.26 to DAC output function
}

// -----------------------------
// Microsecond Delay Using Timer 0
// -----------------------------
void udelay(unsigned int delay_in_us) {
    T0TCR = 0x02; // Reset Timer 0
    T0PR  = (Fpclk / 1000000) - 1;  // Prescaler for 1us per tick
    T0MR0 = delay_in_us;           // Match after delay_in_us ticks
    T0MCR = 0x04;                  // Stop on match
    T0TCR = 0x01;                  // Start Timer 0

    // Wait until timer stops (match reached)
    while (T0TC < delay_in_us);

    T0TCR = 0x02; // Reset Timer 0 again
}

// -----------------------------
// Play Tone on DAC
// -----------------------------
void play_tone(unsigned int duration, int period, int vol) {
    int i;
    int cycles = duration / period;

    for (i = 0; i < cycles; i++) {
        // Set DAC to specified volume (bits 15:6)
        DACR = (DACR & 0xFFFF003F) | (vol << 6);
        udelay(period / 2);

        // Set DAC to 0 (silence)
        DACR = (DACR & 0xFFFF003F);
        udelay(period / 2);
    }
}
