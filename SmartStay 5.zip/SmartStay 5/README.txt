Smart Stay Control Hub - v2

Features:
Blinds: represented by two tricolour LEDS where RED = open, GREEN = midway, BLUE = closed
Coffee Machine: run by smart plug, represented by [???]
In-House Lighting: sensitive to variable house modes represented by LED ladder
TV: represented by [??]
Doorbell system: press push button [???] to play chime
Sound System: depending on house modes different ambient music plays
Light Sensor: [???]

Interacting w Display: 
Main Display: on startup opens to central display which presents Smart Stay logo and various control options
	- Blinds: toggle between auto/manual control, where 	automatic follows seasonal control algorithm sensitive to 	light sensor data, manual leads to second display screen 	for selection
	- Season: toggle between summer/winter to help control 		algorithm for blinds for optimal temperature control
	- Coffee: toggle for coffee machine on/off (runs on 	automatic timer w option for manual override via UI and 	also push button [???]
	- House Modes: Can switch between house modes, touch for on 	and again for off, sets multiple home features 	automatically and resets all when turned off
	- '!!' Button: Switches to accessible display, or back to 	regular if already in accessible
Accessible Display: contains same options as main display, w exception of house modes, as designed for elderly/less tech savvy, so bigger text size + remove confusing extra functions
Blind Select Display: when manual blind selection made 